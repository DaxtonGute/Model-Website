"""
    Description: This program is an strategic guessing game in which two player
    place their ships on a grid type board and try to guess where the opponents
    ships are; if a player eliminates all the opponents ships, they win. This
    game is more commonly known as battleship.
    Authors: Ashir Kashyap and Dax Gutekunst
    Date: 04/20/2020
"""
from graphics import *
import time
### For Zelle Color Examples   https://www.rose-hulman.edu/class/cs/csse120/Resources/Graphics/ZelleGraphicsColors/ColorSwatches.jpg
### For Zelle Color Names      https://www.rose-hulman.edu/class/cs/csse120/Resources/Graphics/ZelleGraphicsColors/NamedColors.txt
### For General Zelle Graphics https://mcsp.wartburg.edu/zelle/python/graphics/graphics.pdf

def getInput(prompt, low, high):
    """
    Purpose: Verifies the user typed in a valid response based on the low and high restrictions
    Parameters: The low and high restrictions (int) and the prompt (str)
    Return Value: An acceptable input (int)
    """
    while True:
        userInput = input(prompt)
        try:
            digit = int(userInput)
            if low <= digit <= high:
                return digit
            print("Invalid entry: Must be between %d and %d" % (low, high))
        except ValueError:
            print("Please enter an integer between %d and %d" % (low, high))


def drawShipBody(windowDemension):
    menuWindow = GraphWin("Main Menu", windowDemension, windowDemension)
    menuWindow.setCoords(0, 0, menuWindow.getWidth(), menuWindow.getHeight())
    menuWindow.setBackground("light pink")

    title = Text(Point(.5 * windowDemension, .92 * windowDemension), "WELCOME TO BATTLESHIP!")
    title.setSize(32)
    title.draw(menuWindow)

    shipp1 = Point(.25 * windowDemension, .6 * windowDemension)
    shipp2 = Point(.75 * windowDemension, .4 * windowDemension)
    shipBody = Rectangle(shipp1, shipp2)
    shipBody.setFill("grey")
    shipBody.setOutline("grey")
    shipBody.draw(menuWindow)

    shipSide1 = Polygon(Point(.25 * windowDemension, .6 * windowDemension), Point(.25 * windowDemension, .4 * windowDemension), Point(.1 * windowDemension, .6 * windowDemension))
    shipSide1.setFill("grey")
    shipSide1.setOutline("grey")
    shipSide1.draw(menuWindow)

    shipSide2 = Polygon(Point(.75 * windowDemension, .4 * windowDemension), Point(.75 * windowDemension, .6 * windowDemension), Point(.9 * windowDemension, .6 * windowDemension))
    shipSide2.setFill("grey")
    shipSide2.setOutline("grey")
    shipSide2.draw(menuWindow)

    shipp3 = Point(.35 * windowDemension, .7 * windowDemension)
    shipp4 = Point(.75 * windowDemension, .6 * windowDemension)
    shipTop = Rectangle(shipp3, shipp4)
    shipTop.setFill("DimGray")
    shipTop.setOutline("DimGray")
    shipTop.draw(menuWindow)

    p5 = Point(.60 * windowDemension, .7 * windowDemension)
    p6 = Point(.63 * windowDemension, .75 * windowDemension)
    p7 = Point(.65 * windowDemension, .7 * windowDemension)
    p8 = Point(.68 * windowDemension, .75 * windowDemension)

    shipFunnel1 = Rectangle(p5, p6)
    shipFunnel2 = Rectangle(p7, p8)

    shipFunnel1.setFill("grey0")
    shipFunnel1.setOutline("grey0")
    shipFunnel1.draw(menuWindow)

    shipFunnel2.setFill("grey0")
    shipFunnel2.setOutline("grey0")
    shipFunnel2.draw(menuWindow)

    smoke1 = Polygon(Point(.615 * windowDemension, .77 * windowDemension), Point(.6 * windowDemension, .79 * windowDemension), Point(.615 * windowDemension, .81 * windowDemension), Point(.63 * windowDemension, .79 * windowDemension))
    smoke2 = Polygon(Point(.665 * windowDemension, .77 * windowDemension), Point(.65 * windowDemension, .79 * windowDemension), Point(.665 * windowDemension, .81 * windowDemension), Point(.68 * windowDemension, .79 * windowDemension))

    smoke1.setFill("ivory")
    smoke1.setOutline("ivory")

    smoke2.setFill("ivory")
    smoke2.setOutline("ivory")

    smoke1.draw(menuWindow)
    smoke2.draw(menuWindow)

    p9 = Point(.35 * windowDemension, .5 * windowDemension)
    p10 = Point(.5 * windowDemension, .5 * windowDemension)
    p11 = Point(.65 * windowDemension, .5 * windowDemension)

    window1 = Circle((p9), 30)
    window2 = Circle((p10), 30)
    window3 = Circle((p11), 30)

    window1.setFill("light blue")
    window1.setOutline("black")
    window1.draw(menuWindow)

    window2.setFill("light blue")
    window2.setOutline("black")
    window2.draw(menuWindow)

    window3.setFill("light blue")
    window3.setOutline("black")
    window3.draw(menuWindow)

    return menuWindow


def subTitle(graph, windowDemension):
    centerSubTitle = Point(.5 * windowDemension, .87 * windowDemension)
    subTitleText = Text((centerSubTitle), "An intense strategic guessing game for hardcore battleship gamers")

    subTitleText.setFill("red3")
    subTitleText.setSize(14)
    subTitleText.draw(graph)


def subSubTitle(graph, windowDemension):
    centerSubTitle = Point(.5 * windowDemension, .84 * windowDemension)
    subTitleText = Text((centerSubTitle), "Recommended Age: 13+")

    subTitleText.setFill("red3")
    subTitleText.setSize(14)
    subTitleText.draw(graph)


def instructionsButton(graph, windowDemension):
    p1 = Point(.2 * windowDemension, .35 * windowDemension)
    p2 = Point(.8 * windowDemension, .225 * windowDemension)
    instructionsButton = Rectangle(p1, p2)

    instructionsButton.setFill("light green")
    instructionsButton.setOutline("black")
    instructionsButton.draw(graph)

    centerButton = Point(.5 * windowDemension, .2875 * windowDemension)
    howToPlayText = Text((centerButton), "How To Play")
    howToPlayText.setSize(30)
    howToPlayText.draw(graph)


def StartGameButton(graph, windowDemension):
    p1 = Point(.2 * windowDemension, .2 * windowDemension)
    p2 = Point(.8 * windowDemension, .0725 * windowDemension)
    StartGameButton = Rectangle(p1, p2)

    StartGameButton.setFill("light green")
    StartGameButton.setOutline("black")
    StartGameButton.draw(graph)

    centerButton = Point(.5 * windowDemension, .13625 * windowDemension)
    StartGameText = Text((centerButton), "Play A Game")
    StartGameText.setSize(30)
    StartGameText.draw(graph)


def clickButton(window, windowDemension):
    xPlayLow = .2 * windowDemension
    xPlayHigh = .8 * windowDemension

    xInstructionsLow = .82 * windowDemension
    xInstructionsHigh = .98 * windowDemension

    yLoadGameLow = .225 * windowDemension
    yLoadGameHigh = .35 * windowDemension

    yStartGameLow = .0725 * windowDemension
    yStartGameHigh = .2 * windowDemension

    yInstructionsLow = .02 * windowDemension
    yinstructionsHigh = .08 * windowDemension

    LoadGameButton = Rectangle(Point(xPlayLow, yLoadGameLow), Point(xPlayHigh, yLoadGameHigh))
    LoadGameButton.setFill("orange")
    LoadGameButton.setOutline("orange")
    LoadGameText = Text(Point(xPlayLow + .16 * windowDemension, yLoadGameLow + .06 * windowDemension), "Start Game")
    LoadGameText.setSize(5 + int(windowDemension/25))
    LoadGameText.setTextColor("ivory")
    LoadGameButton.draw(window)
    LoadGameText.draw(window)

    StartGameButton = Rectangle(Point(xPlayLow, yStartGameLow), Point(xPlayHigh, yStartGameHigh))
    StartGameButton.setFill("orange")
    StartGameButton.setOutline("orange")
    StartGameText = Text(Point(xPlayLow + .16 * windowDemension, yStartGameLow + .06 * windowDemension), "Load Game")
    StartGameText.setSize(5 + int(windowDemension/25))
    StartGameText.setTextColor("ivory")
    StartGameButton.draw(window)
    StartGameText.draw(window)

    InstructionsButton = Circle(Point(.95 * windowDemension, .05 * windowDemension), .03 * windowDemension)
    InstructionsButton.setFill("Green")
    InstructionsButton.setOutline("Green")
    InstructionsText = Text(Point(.95 * windowDemension, .05 * windowDemension), "?")
    InstructionsText.setSize(5 + int(windowDemension/50))
    InstructionsText.setTextColor("ivory")
    InstructionsButton.draw(window)
    InstructionsText.draw(window)

    userClick = window.checkMouse()
    xCoor = userClick.getX()
    yCoor = userClick.getY()

    if xPlayLow <= xCoor <= xPlayHigh and yLoadGameLow <= yCoor <= yLoadGameHigh:
        print("Go to Load a game!")
        loadGame = LoadGame(windowDemension)
    elif xPlayLow <= xCoor <= xPlayHigh and yStartGameLow <= yCoor <= yStartGameHigh:
        print("Go to play a game!")
        StartGame = StartGameButton(graph, windowDemension)
    elif xInstructionsLow <= xCoor <= xInstructionsHigh and yInstructionsLow <= yCoor <= yinstructionsHigh:
        instructionsPage = instructions(window, windowDemension)
    else:
        print("Not a button!")


def instructions(window, windowDemension):
    window.close() #replacing the window
    instructionsPage = GraphWin("Instructions Page", 960, 640)
    instructionsPage.setCoords(0, 0, 750, 750)

    instructions = Image(Point(960 * .39, 640 * .585), "instructions1.gif" )
    instructions.draw(instructionsPage)
    for i in range(2, 9): # it is flashing
        instructions.undraw()
        instructions = Image(Point(960 * .39, 640 * .585), "instructions%i.gif" % i)
        instructions.draw(instructionsPage) #use getMouse to make it stop as condition and and while loop
        time.sleep(1)
    wait = input("Dont forget to reinitialize the original window")



def main():
    windowDemension = int(input("Enter the demensions of the window: "))
    graph = drawShipBody(windowDemension)
    subTitle(graph, windowDemension)
    subSubTitle(graph, windowDemension)
    while True:
        clickButton(graph, windowDemension)
    instructionsPage = instructions(windowDemension)
    quit = input("quit?")


main()
