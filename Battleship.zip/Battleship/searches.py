"""
Description: This program creates two separate algoritmns (linear search and binary
search) These can be used in separate programs or can simply be tested in this
one for functionality.
Name: Daxton Gutekunst
Date: Mar. 16 2019
"""
from math import *

def linearSearch(x, L):
    """
    Purpose: A searching algorithm that searches for a specific item in a list
    (not conditions are required) by going through each item. It then returns the position
    it was found at (if any)
    Parameters: the item to look for (could be anything but in this case)[int],
    the list to scan through [list of ints]
    Return Val: location of item if x is in L, -1 if not [Int]
    """
    steps = 0
    for item in L:
        steps += 1
        if item == x:
            return steps
    # only gets here if not found!
    return -1

def binarySearch(x, L):
    """
    Purpose: A searching algorithm that searches for a specific item in a list
    (list must be ordered) by picking the middle item and checking if the item is
    lower or higher: the algoritnm then limits the search to that half and then repeats.
    It then returns the position it was found at (if any)
    Parameters: the item to look for (could be anything but in this case)[int],
    the list to scan through [list of ints]
    Return Val: location of item if x is in L, -1 if not [Int]
    """
    if len(L) == 0:
        return -1
    lowPoint = 0
    highPoint = len(L) - 1
    steps = 0
    while True:
        midPoint = (highPoint - lowPoint)//2 + lowPoint
        steps += 1
        if x == L[midPoint]:
            return midPoint
        elif x < L[midPoint]:
            highPoint = midPoint - 1
        elif x > L[midPoint]:
            lowPoint = midPoint + 1
        if highPoint < lowPoint:
            return -1


if __name__ == "__main__":
    # Valid Tests
    L = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    x = 5
    linearCompletedSearch = linearSearch(x, L)
    print("Linear Search: %3d  %s  %7i" % (x, str(L), linearCompletedSearch))
    assert linearCompletedSearch!=-1
    binaryCompletedSearch = binarySearch(x, L)
    print("Binary Search: %3d  %s  %7i" % (x, str(L), binaryCompletedSearch))
    assert binaryCompletedSearch!=-1

    #Invalid Tests
    x = 500
    linearCompletedSearch = linearSearch(x, L)
    print("Linear Search: %3d  %s  %7i" % (x, str(L), linearCompletedSearch))
    assert linearCompletedSearch==-1
    binaryCompletedSearch = binarySearch(x, L)
    print("Binary Search: %3d  %s  %7s" % (x, str(L), binaryCompletedSearch))
    assert binaryCompletedSearch==-1
    binaryCompletedSearch = binarySearch(5, [])
    print("Binary Search: %3d  %s  %7s" % (x, str(L), binaryCompletedSearch))
    assert binaryCompletedSearch==-1
