"""
    Description: This program is an strategic guessing game in which two player
    place their ships on a grid type board and try to guess where the opponents
    ships are; if a player eliminates all the opponents ships, they win. This
    game is more commonly known as battleship.
    Authors: Dax Gutekunst and Ashir Kashyap
    Date: 05/27/2020
"""
from graphics import *
import time
def drawShipBody(windowDimension):
    """
    Purpose: Draws the graphics for the ship body
    Parameters: The square window dimension (int)
    Return Value: The menu window (graph object)
    """
    menuWindow = GraphWin("Main Menu", windowDimension, windowDimension)
    menuWindow.setCoords(0, 0, menuWindow.getWidth(), menuWindow.getHeight())
    menuWindow.setBackground("light pink")

    title = Text(Point(.5 * windowDimension, .92 * windowDimension), "WELCOME TO BATTLESHIP!")
    title.draw(menuWindow)
    try:
        title.setSize(5 + int(windowDimension/25))
    except:
        title.setSize(32)

    shipp1 = Point(.25 * windowDimension, .6 * windowDimension)
    shipp2 = Point(.75 * windowDimension, .4 * windowDimension)
    shipBody = Rectangle(shipp1, shipp2)
    shipBody.setFill("grey")
    shipBody.setOutline("grey")
    shipBody.draw(menuWindow)

    shipSide1 = Polygon(Point(.25 * windowDimension, .6 * windowDimension), Point(.25 * windowDimension, .4 * windowDimension), Point(.1 * windowDimension, .6 * windowDimension))
    shipSide1.setFill("grey")
    shipSide1.setOutline("grey")
    shipSide1.draw(menuWindow)

    shipSide2 = Polygon(Point(.75 * windowDimension, .4 * windowDimension), Point(.75 * windowDimension, .6 * windowDimension), Point(.9 * windowDimension, .6 * windowDimension))
    shipSide2.setFill("grey")
    shipSide2.setOutline("grey")
    shipSide2.draw(menuWindow)

    shipp3 = Point(.35 * windowDimension, .7 * windowDimension)
    shipp4 = Point(.75 * windowDimension, .6 * windowDimension)
    shipTop = Rectangle(shipp3, shipp4)
    shipTop.setFill("DimGray")
    shipTop.setOutline("DimGray")
    shipTop.draw(menuWindow)

    p5 = Point(.60 * windowDimension, .7 * windowDimension)
    p6 = Point(.63 * windowDimension, .75 * windowDimension)
    p7 = Point(.65 * windowDimension, .7 * windowDimension)
    p8 = Point(.68 * windowDimension, .75 * windowDimension)

    shipFunnel1 = Rectangle(p5, p6)
    shipFunnel2 = Rectangle(p7, p8)

    shipFunnel1.setFill("grey0")
    shipFunnel1.setOutline("grey0")
    shipFunnel1.draw(menuWindow)

    shipFunnel2.setFill("grey0")
    shipFunnel2.setOutline("grey0")
    shipFunnel2.draw(menuWindow)

    smoke1 = Polygon(Point(.615 * windowDimension, .77 * windowDimension), Point(.6 * windowDimension, .79 * windowDimension), Point(.615 * windowDimension, .81 * windowDimension), Point(.63 * windowDimension, .79 * windowDimension))
    smoke2 = Polygon(Point(.665 * windowDimension, .77 * windowDimension), Point(.65 * windowDimension, .79 * windowDimension), Point(.665 * windowDimension, .81 * windowDimension), Point(.68 * windowDimension, .79 * windowDimension))

    smoke1.setFill("ivory")
    smoke1.setOutline("ivory")

    smoke2.setFill("ivory")
    smoke2.setOutline("ivory")

    smoke1.draw(menuWindow)
    smoke2.draw(menuWindow)

    p9 = Point(.35 * windowDimension, .5 * windowDimension)
    p10 = Point(.5 * windowDimension, .5 * windowDimension)
    p11 = Point(.65 * windowDimension, .5 * windowDimension)

    window1 = Circle((p9), 30)
    window2 = Circle((p10), 30)
    window3 = Circle((p11), 30)

    window1.setFill("light blue")
    window1.setOutline("black")
    window1.draw(menuWindow)

    window2.setFill("light blue")
    window2.setOutline("black")
    window2.draw(menuWindow)

    window3.setFill("light blue")
    window3.setOutline("black")
    window3.draw(menuWindow)

    return menuWindow


def subTitle(graph, windowDimension):
    """
    Purpose: Draws the sub title for the main menu page
    Parameters: The graph (graph object) and the square window dimension (int)
    Return Value: None
    """
    centerSubTitle = Point(.5 * windowDimension, .87 * windowDimension)
    subTitleText = Text((centerSubTitle), "An intense strategic guessing game for hardcore battleship gamers")

    subTitleText.setFill("red3")
    try:
        subTitleText.setSize(5 + int(windowDimension/70))
    except:
        subTitleText.setSize(32)
    subTitleText.draw(graph)


def subSubTitle(graph, windowDimension):
    """
    Purpose: Draws the sub sub title for the main menu page
    Parameters: The graph (graph object) and the square window dimension (int)
    Return Value: None
    """
    centerSubTitle = Point(.5 * windowDimension, .84 * windowDimension)
    subTitleText = Text((centerSubTitle), "Recommended Age: 13+")

    subTitleText.setFill("red3")
    try:
        subTitleText.setSize(5 + int(windowDimension/100))
    except:
        subTitleText.setSize(32)
    subTitleText.draw(graph)




def StartGameButton(graph, windowDimension):
    """
    Purpose: Draws the start game button for the main menu page
    Parameters: The graph (graph object) and the square window dimension (int)
    Return Value: None
    """
    p1 = Point(.2 * windowDimension, .2 * windowDimension)
    p2 = Point(.8 * windowDimension, .0725 * windowDimension)
    StartGameButton = Rectangle(p1, p2)

    StartGameButton.setFill("light green")
    StartGameButton.setOutline("black")
    StartGameButton.draw(graph)

    centerButton = Point(.5 * windowDimension, .13625 * windowDimension)
    StartGameText = Text((centerButton), "Load Game")
    try:
        StartGameText.setSize(5 + int(windowDimension/25))
    except:
        StartGameText.setSize(32)
    StartGameText.draw(graph)


def clickButton(window, windowDimension):
    """
    Purpose: Draws the buttons for the main menu page and checks if the user
    has clicked them
    Parameters: The graph (graph object) and the square window dimension (int)
    Return Value: None
    """
    xPlayLow = .2 * windowDimension
    xPlayHigh = .8 * windowDimension
    xInstructionsLow = .82 * windowDimension
    xInstructionsHigh = .98 * windowDimension
    yLoadGameLow = .225 * windowDimension
    yLoadGameHigh = .35 * windowDimension
    yStartGameLow = .0725 * windowDimension
    yStartGameHigh = .2 * windowDimension
    yInstructionsLow = .02 * windowDimension
    yinstructionsHigh = .08 * windowDimension
    LoadGameButton = Rectangle(Point(xPlayLow, yLoadGameLow), Point(xPlayHigh, yLoadGameHigh))
    LoadGameButton.setFill("light green")
    LoadGameButton.setOutline("black")
    LoadGameText = Text(Point(xPlayLow + .16 * windowDimension, yLoadGameLow + .06 * windowDimension), "  Start Game")
    try:
        LoadGameText.setSize(5 + int(windowDimension/25))
    except:
        LoadGameText.setSize(32)
    LoadGameText.setTextColor("ivory")
    LoadGameButton.draw(window)
    LoadGameText.draw(window)
    StartGameButton = Rectangle(Point(xPlayLow, yStartGameLow), Point(xPlayHigh, yStartGameHigh))
    StartGameButton.setFill("light green")
    StartGameButton.setOutline("black")
    StartGameText = Text(Point(xPlayLow + .16 * windowDimension, yStartGameLow + .06 * windowDimension), "  Load Game")
    try:
        StartGameText.setSize(5 + int(windowDimension/25))
    except:
        StartGameText.setSize(32)
    StartGameText.setTextColor("ivory")
    StartGameButton.draw(window)
    StartGameText.draw(window)
    InstructionsButton = Circle(Point(.95 * windowDimension, .05 * windowDimension), .03 * windowDimension)
    InstructionsButton.setFill("Green")
    InstructionsButton.setOutline("Green")
    InstructionsText = Text(Point(.95 * windowDimension, .05 * windowDimension), "?")
    try:
        InstructionsText.setSize(5 + int(windowDimension/50))
    except:
        InstructionsText.setSize(32)
    InstructionsText.setTextColor("ivory")
    InstructionsButton.draw(window)
    InstructionsText.draw(window)
    notValidEndPick = True
    while notValidEndPick:
        userClick = window.getMouse()
        xCoor = userClick.getX()
        yCoor = userClick.getY()
        if xPlayLow <= xCoor <= xPlayHigh and yLoadGameLow <= yCoor <= yLoadGameHigh:
            window.close()
            newWindow = startNewGame(windowDimension)
            newWindow.close()
            notValidEndPick = False
        elif xPlayLow <= xCoor <= xPlayHigh and yStartGameLow <= yCoor <= yStartGameHigh:
            window.close()
            newWindow = loadGame(windowDimension)
            newWindow.close()
            notValidEndPick = False
        elif xInstructionsLow <= xCoor <= xInstructionsHigh and yInstructionsLow <= yCoor <= yinstructionsHigh:
            instructions(window, windowDimension)
    window.close()


def instructions(window, windowDimension):
    """
    Purpose: Draws the instructions question mark(button) for the main menu page
    Parameters: The graph (graph object) and the square window dimension (int)
    Return Value: None
    """
    imageWidth = 960
    imageHeight = 640
    window = GraphWin("Instructions Page", imageWidth, imageHeight)
    window.setCoords(0, 0, 750, 750)
    instructions = Image(Point(imageWidth * .39, imageHeight * .585), "instructions1.gif" )
    instructions.draw(window)
    click = Point(0, 0)
    image = 2

    while not(19 <= click.getX() <= 77 and 680 <= click.getY() <= 720):
        click = window.checkMouse()
        try:
            click.getX()
        except:
            click = Point(0, 0)
        instructions.undraw()
        instructions = Image(Point(imageWidth * .39, imageHeight * .585), "instructions%i.gif" % image)
        instructions.draw(window)
        backButton = Rectangle(Point(19, 680), Point(77, 720))
        backButton.setFill("Blue")
        backText = Text(Point(50, 700), "<-----")
        try:
            backText.setSize(5 + int(windowDimension/40))
        except:
            backText.setSize(32)
        backButton.draw(window)
        backText.draw(window)
        time.sleep(3)
        image += 1
        if image == 9:
            image = 1
    window.close()


def menu(windowDimension):
    """
    Purpose: Draws/runs all the code for the main menu page
    Parameters: The square window dimension (int)
    Return Value: None
    """
    graph = drawShipBody(windowDimension)
    subTitle(graph, windowDimension)
    subSubTitle(graph, windowDimension)
    clickButton(graph, windowDimension)


def readFile(filename):
    """
    Purpose: Reads a file (in this case a list of numbers and booleans) and
    reads in the data
    Parameters: A filename
    Returns: The shipLocationsOne (list), the spotsFiredOne (list),
    the shipLocationsTwo (list), and the spotsFiredTwo (list)
    """
    shipLocationsOne =[]
    spotsFiredOne = []
    shipLocationsTwo = []
    spotsFiredTwo = []
    file = open(filename, "r")
    words = []
    for line in file:
        titleAndData = line.split(": ")
        title = titleAndData[0]
        data = str(titleAndData[1]).split("]")
        data.pop()
        expandedData = []
        for row in data:
            expandedData.append(row.strip("[").strip("\n").split(", "))
        if title == "Player 1 Shots" or title == "Player 2 Shots":
            for row in range(len(expandedData)):
                for collumn in range(len(expandedData[row])):
                    expandedData[row][collumn] = (expandedData[row][collumn] == "True")
        else:
            for row in range(len(expandedData)):
                for collumn in range(len(expandedData[row])):
                    expandedData[row][collumn] = int((expandedData[row][collumn]).strip())

        if title == "Player 1 Ships":
            shipLocationsOne = expandedData
        elif title == "Player 1 Shots":
            spotsFiredOne = expandedData
        elif title == "Player 2 Ships":
            shipLocationsTwo = expandedData
        elif title == "Player 2 Shots":
            spotsFiredTwo = expandedData
    file.close()
    return shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo


def writeFile(filename, shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo):
    """
    Purpose: Reads a file (in this case a list of numbers and booleans) and
    writes it into the four appropriate lists
    Parameters: A filename, shipLocationsOne (list), spotsFiredOne (list),
    shipLocationsTwo (list), and spotsFiredTwo (list)
    Returns: None
    """
    file = open(filename, "w")
    file.write("Player 1 Ships: ")
    for row in shipLocationsTwo:
        file.write(str(row))
    file.write("\nPlayer 1 Shots: ")
    for row in spotsFiredTwo:
        file.write(str(row))
    file.write("\nPlayer 2 Ships: ")
    for row in shipLocationsOne:
        file.write(str(row))
    file.write("\nPlayer 2 Shots: ")
    for row in spotsFiredOne:
        file.write(str(row))

    file.close()


def pickShipPositions(window, shipLocations, windowDimension):
    """
    Purpose: Reads a file (in this case a list of numbers and booleans) and
    reads in the data
    Parameters: The window (graph object), the shipLocations (list), and the
    windowDimension (int)
    Returns: The window (graph object), and the shipLocations (list)
    """
    shipLengthList = [5,4,3,3,2]
    shipBody = []
    defaultRotation = "horizontal"
    confirmButton = Rectangle(Point(windowDimension*0.3, windowDimension*0.01), Point(windowDimension*0.7, windowDimension*0.09))
    confirmButton.setFill("dark green")
    confirmButton.setOutline("dark green")
    confirmText = Text(Point(windowDimension*0.35, windowDimension*0.05), "       Confirm")
    try:
        confirmText.setSize(int(5 + (windowDimension * 0.03)))
    except:
        confirmText.setSize(32)
    confirmText.setTextColor("Ivory")
    rotatePointA = Point(0.82*windowDimension, 0.01*windowDimension)
    rotatePointB = Point(0.9*windowDimension, 0.09*windowDimension)
    rotateButton = Rectangle(rotatePointA, rotatePointB)
    rotateButton.setFill("green")
    rotateButton.setOutline("green")
    rotateText = Text(Point(windowDimension*0.845, windowDimension*0.05), "  ®")
    try:
        rotateText.setSize(int(5 + (windowDimension * 0.04)))
    except:
        rotateText.setSize(32)
    rotateText.setTextColor("Ivory")
    for i in range(len(shipLengthList)):
        alreadyDrawn = False
        confirmButton.draw(window)
        confirmText.draw(window)
        rotateButton.draw(window)
        rotateText.draw(window)
        notConfirmed = True
        shipBody.append(Rectangle(Point(windowDimension*0.1, windowDimension*0.11), Point(windowDimension*0.1, windowDimension*0.11)))
        while notConfirmed:
            VALIDX = False
            VALIDY = False
            mouseClick = window.getMouse()
            if 0.82*windowDimension <= mouseClick.getX() <= 0.9*windowDimension and 0.01*windowDimension <= mouseClick.getY() <= 0.09*windowDimension:
                if defaultRotation == "horizontal":
                    defaultRotation = "vertical"
                else:
                    defaultRotation = "horizontal"
            if 0.1*windowDimension <= mouseClick.getX() <= 0.9*windowDimension:
                VALIDX = True
            if 0.1*windowDimension <= mouseClick.getY() <= 0.9*windowDimension:
                VALIDY = True

            if VALIDX and VALIDY:
                shipBody[i].undraw()
                if shipLengthList[i] % 2 == 0:
                    if defaultRotation == "vertical":
                        xCoor = int(((mouseClick.getX()/windowDimension)-0.1)//0.08)
                        yCoor = int(((mouseClick.getY()/windowDimension)-0.15)//0.08) + 0.5
                    else:
                        xCoor = int(((mouseClick.getX()/windowDimension)-0.15)//0.08) +0.5
                        yCoor = int(((mouseClick.getY()/windowDimension)-0.1)//0.08)
                    shipBody[i], shipPositions = drawShip(xCoor, yCoor, defaultRotation, shipLengthList[i], windowDimension, window)
                    shipBody[i].draw(window)
                    alreadyDrawn = True
                else:
                    xCoor = int(((mouseClick.getX()/windowDimension)-0.1)//0.08)
                    yCoor = int(((mouseClick.getY()/windowDimension)-0.1)//0.08)
                    shipBody[i], shipPositions = drawShip(xCoor, yCoor, defaultRotation, shipLengthList[i], windowDimension, window)
                    shipBody[i].draw(window)
                    alreadyDrawn = True

            if 0.3*windowDimension <= mouseClick.getX() <= 0.7*windowDimension and 0.01*windowDimension <= mouseClick.getY() <= 0.09*windowDimension and alreadyDrawn:
                notConfirmed = False
                confirmButton.undraw()
                confirmText.undraw()
                rotateButton.undraw()
                rotateText.undraw()
        for tuple in shipPositions:
            shipLocations[int(tuple[0])][int(tuple[1])] = i + 1

    return window, shipLocations


def fireBomb(window, windowDimension, shipLocations, spotsFired, attackPoint):
    """
    Purpose: Creates a new type of attack that has a wider spread known as
    the fire bomb
    Parameters: The window (graph object), the windowDimension (int), the
    shipLocations (list), the spotsFired (list), and the attackPoint (point object)
    Returns: The window (graph object), and the spotsFired (list)
    """
    VALIDX = False
    VALIDY = False
    if 0.18*windowDimension <= attackPoint.getX() <= 0.82*windowDimension:
        VALIDX = True
    if 0.18*windowDimension <= attackPoint.getY() <= 0.82*windowDimension:
        VALIDY = True

    xCoor = int(((attackPoint.getX()/windowDimension)-0.1)//0.08)
    yCoor = int(((attackPoint.getY()/windowDimension)-0.1)//0.08)

    if VALIDX and VALIDY:
        window = drawHitIndicator(shipLocations, yCoor, xCoor, windowDimension, window)
        spotsFired[9-yCoor][xCoor] = True
        window = drawHitIndicator(shipLocations, yCoor, xCoor - 1, windowDimension, window)
        spotsFired[9-yCoor][xCoor -1] = True
        window = drawHitIndicator(shipLocations, yCoor - 1, xCoor, windowDimension, window)
        spotsFired[9-yCoor-1][xCoor] = True
        window = drawHitIndicator(shipLocations, yCoor, xCoor + 1, windowDimension, window)
        spotsFired[9-yCoor][xCoor +1] = True
        window = drawHitIndicator(shipLocations, yCoor + 1, xCoor, windowDimension, window)
        spotsFired[9-yCoor+1][xCoor] = True
        return window, spotsFired


def fireWeapon(window, windowDimension, shipLocations, spotsFired):
    """
    Purpose: Writes instruction text to help the user fire
    Parameters: The window (graph object), the windowDimension (int),
    the shipLocations (list), and the spotsFired (list)
    Returns: The window (graph object), and the spotsFired (list)
    """
#    defaultWeapon = "cannon"
#    cannonPointA = Point(0.92*windowDimension, 0.83*windowDimension)
#    cannonPointB = Point(0.98*windowDimension, 0.89*windowDimension)
#    cannonButton = Rectangle(cannonPointA, cannonPointB)
#    cannonButton.setFill("dark red")
#    cannonButton.setOutline("dark red")
    #bombPointA = Point(0.92*windowDimension, 0.75*windowDimension)
    #bombPointB = Point(0.98*windowDimension, 0.81*windowDimension)
    #bombButton = Rectangle(bombPointA, bombPointB)
    #bombButton.setFill("red")
    #bombButton.setOutline("red")
#    cannonButton.draw(window)
    #bombButton.draw(window)
    anotherClick = True
    fireText = Text(Point(0.5*windowDimension, 0.05*windowDimension), "Click on a square to fire!")
    fireText.setTextColor("orange")
    try:
        fireText.setSize(5+int(windowDimension/25))
    except:
        fireText.setSize(32)
    fireText.draw(window)
    while anotherClick: # change to a boolean flag function for continueing
        clickPoint = window.getMouse()
        #if 0.92*windowDimension <= clickPoint.getX() <= 0.98*windowDimension and 0.83*windowDimension <= clickPoint.getY() <= 0.89*windowDimension:
        #    cannonButton.setFill("dark red")
        #    cannonButton.setOutline("dark red")
            #bombButton.setFill("red")
            #bombButton.setOutline("red")
        #    defaultWeapon = "cannon"
    #    elif 0.92*windowDimension <= clickPoint.getX() <= 0.98*windowDimension and 0.75*windowDimension <= clickPoint.getY() <= 0.81*windowDimension:
            #cannonButton.setFill("red")
            #cannonButton.setOutline("red")
            #bombButton.setFill("dark red")
            #bombButton.setOutline("dark red")
            #defaultWeapon = "bomb"
        if 0.1*windowDimension <= clickPoint.getX() <= 0.9*windowDimension and 0.1*windowDimension <= clickPoint.getY() <= 0.9*windowDimension:
    #        if defaultWeapon == "cannon":
            window, spotsFired = fireCannon(window, windowDimension, shipLocations, spotsFired, clickPoint)
        #    else:
            #    :
                #    window, spotsFired = fireBomb(window, windowDimension, shipLocations, spotsFired, clickPoint)
            #    except:
            #        pass
            anotherClick = False
    fireText.undraw()
    return window, spotsFired


def fireCannon(window, windowDimension, shipLocations, spotsFired, attackPoint):
    """
    Purpose: Fires the user's attack
    Parameters: The window (graph object), the windowDimension (int),
    the shipLocations (list), the spotsFired (list), and the attackPoint (point object)
    Returns: The window (graph object), and the spotsFired (list)
    """
    VALIDX = False
    VALIDY = False
    if 0.1*windowDimension <= attackPoint.getX() <= 0.9*windowDimension:
        VALIDX = True
    if 0.1*windowDimension <= attackPoint.getY() <= 0.9*windowDimension:
        VALIDY = True

    xCoor = int(((attackPoint.getX()/windowDimension)-0.1)//0.08)
    yCoor = int(((attackPoint.getY()/windowDimension)-0.1)//0.08)

    if VALIDX and VALIDY and spotsFired[9-yCoor][xCoor] != True:
        window = drawHitIndicator(shipLocations, yCoor, xCoor, windowDimension, window)
        spotsFired[9-yCoor][xCoor] = True
        return window, spotsFired


def drawHitIndicator(shipLocations, yCoor, xCoor, windowDimension, window):
    """
    Purpose: Draws a hit where the user fired
    Parameters: The shipLocations (list), the yCoor (point object), the xCoor (point object),
    the windowDimension (int), and the window (graph object)
    Returns: The window (graph object)
    """
    xWindowCoor = ((0.1 + (0.08 * xCoor)) * windowDimension) + (windowDimension*0.04)
    yWindowCoor = ((0.1 + (0.08 * yCoor)) * windowDimension) + (windowDimension*0.04)
    circleCenter = Point(xWindowCoor, yWindowCoor)
    if shipLocations[9-yCoor][xCoor] != 0:
        circle = Circle(circleCenter, windowDimension*0.03)
        circle.setFill("light pink")
        circle.setOutline("red")
    else:
        circle = Circle(circleCenter, windowDimension*0.02)
        circle.setFill("purple")
        circle.setOutline("black")
    circle.draw(window)
    return window


def getInput(prompt):
    """
    Purpose: Verifies the user typed in a valid response based on the low and high restrictions
    Parameters: The low and high restrictions (int) and the prompt (str)
    Return Value: An acceptable input (int)
    """
    low = 500
    high = 1200
    while True:
        userInput = input(prompt)
        try:
            digit = int(userInput)
            if low <= digit <= high:
                return digit
            print("Invalid entry: Must be between %d and %d" % (low, high))
        except ValueError:
            print("Please enter an integer between %d and %d" % (low, high))


def drawGrid(window, windowDimension):
    """
    Purpose: Draws the battleship grid
    Parameters: The window (graph object), the windowDimension (int)
    Returns: The window (graph object)
    """
    """SET IN STONE"""
    for i in range(0,11):
        incrementBuffer = (0.1 + (0.08 * i)) * windowDimension
        topBuffer = 0.9 * windowDimension
        topPoint = Point(incrementBuffer, topBuffer)
        bottomBuffer = 0.1 * windowDimension
        bottomPoint = Point(incrementBuffer, bottomBuffer)
        verticalLine = Line(topPoint, bottomPoint)
        verticalLine.draw(window)

        leftPoint = Point(topBuffer, incrementBuffer)
        rightPoint = Point(bottomBuffer, incrementBuffer)
        horizontalLine = Line(leftPoint, rightPoint)
        horizontalLine.draw(window)

    return window

def drawShip(xCoor, yCoor, rotation, shipLength, windowDimension, window):
    """
    Purpose: Draws all the ships used in the game
    Parameters: The xCoor (point object), the yCoor (point object),
    the rotation (str), the shipLength (int), the windowDimension (int), and
    the window (graph object)
    Returns: The shipBody (rectangle object) and the shipPlacement (list)
    """
    if rotation == "vertical":
        topOffset = int(((9-yCoor) + (shipLength/2)) - 9)
        bottomOffset  = int((shipLength/2) - (9-yCoor))
        if topOffset > 0:
            yCoor = yCoor + topOffset
        elif bottomOffset > 0:
            yCoor = yCoor - bottomOffset
    else:
        rightOffset = int((xCoor + (shipLength/2)) - 9)
        leftOffset  = int((shipLength/2) - xCoor)
        if rightOffset > 0:
            xCoor = xCoor - rightOffset
        elif leftOffset > 0:
            xCoor = xCoor + leftOffset
    xyInlay = 0.01 * windowDimension
    shipPlacement = []
    if rotation == "vertical":
        xFirstPointCoor = ((0.1 + (0.08 * xCoor)) * windowDimension) + xyInlay
        yFirstPointCoor = ((0.1 + (0.08 * (yCoor-(shipLength-1)/2))) * windowDimension) +xyInlay
        xSecondPointCoor = ((0.1 + (0.08 * (xCoor + 1))) * windowDimension) - xyInlay
        ySecondPointCoor = ((0.1 + (0.08 * (yCoor + ((shipLength-1)/2) + 1))) * windowDimension) -xyInlay
        if shipLength%2 == 1:
            for i in range(int(-(shipLength-1)/2), int(((shipLength-1)/2) + 1)):
                shipPlacement.append((9-yCoor-i, xCoor))
        else:
            for i in range(int(-(shipLength-1)/2)-1, int(((shipLength-1)/2) + 1)):
                shipPlacement.append((9-yCoor-i, xCoor))
    else:
        xFirstPointCoor = ((0.1 + (0.08 * (xCoor - (shipLength-1)/2))) * windowDimension) + xyInlay
        yFirstPointCoor = ((0.1 + (0.08 * yCoor)) * windowDimension) +xyInlay
        xSecondPointCoor = ((0.1 + (0.08 * (xCoor + ((shipLength-1)/2) + 1))) * windowDimension) - xyInlay
        ySecondPointCoor = ((0.1 + (0.08 * (yCoor + 1))) * windowDimension) -xyInlay
        if shipLength%2 == 1:
            for i in range(int(-(shipLength-1)/2), int(((shipLength-1)/2) + 1)):
                shipPlacement.append((9-yCoor,xCoor+i))
        else:
            for i in range(int(-(shipLength-1)/2), int(((shipLength-1)/2) + 2)):
                shipPlacement.append((9-yCoor, xCoor+i))

    p1 = Point(xFirstPointCoor, yFirstPointCoor)
    p2 = Point(xSecondPointCoor, ySecondPointCoor)
    shipBody = Rectangle(p1, p2)
    shipBody.setFill("dark blue")
    shipBody.setOutline("dark blue")
    return shipBody, shipPlacement


def setUpWindow(windowDimension):
    """
    Purpose: Sets up the window based on the user's desired window dimension
    Parameters: The windowDimension (int)
    Returns: The window (graph object)
    """
    window = GraphWin("Battleship", windowDimension, windowDimension)
    window.setCoords(0, 0, window.getWidth(), window.getHeight())
    window.setBackground("light blue")
    window = drawGrid(window, windowDimension)
    titlePoint = Point(0.1 * windowDimension, 0.95 * windowDimension)
    titleText = "Battleships"
    titleText = " " * (len(titleText) + 5) + titleText
    title = Text(titlePoint, titleText)
    titleSize = int(5 + (windowDimension * 0.03))
    try:
        title.setSize(titleSize)
    except:
        title.setSize(32)
    title.draw(window)
    return window


def startNewGame(windowDimension):
    """
    Purpose: Start a new game
    Parameters: The windowDimension (int)
    Returns: The window (graph object)
    """
    shipLocationsOne = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
    spotsFiredOne = [[False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False]]
    shipLocationsTwo = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],\
                        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
    spotsFiredTwo = [[False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False],\
                  [False, False, False, False, False, False, False, False, False, False]]
    window = setUpWindow(windowDimension)
    rotatePointA = Point(0.82*windowDimension, 0.01*windowDimension)
    rotatePointB = Point(0.9*windowDimension, 0.09*windowDimension)
    moveText = Text(Point(windowDimension*0.8, windowDimension*0.95), "Your Board")
    window, shipLocationsOne = pickShipPositions(window, shipLocationsOne, windowDimension)
    moveText.setTextColor("dark red")
    try:
        moveText.setSize(5 + int(windowDimension/25))
    except:
        moveText.setSize(32)
    moveText.draw(window)
    writeFile("battleship.data", shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo)

    return window


def drawShots(spotsFired, shipLocations, window):
    """
    Purpose: Draws the user's shots
    Parameters: The spotsFired (list), the shipLocations (list), and the
    window (graph object)
    Returns: The window (graph object)
    """
    for row in range(len(spotsFired)):
        for collumn in range(len(spotsFired[row])):
            if spotsFired[9-row][collumn] == True:
                window = drawHitIndicator(shipLocations, row, collumn, window.getWidth(), window)
    return window


def drawFleet(shipLocations, window):
    """
    Purpose: Creates the fleet of ships and returns them
    Parameters: The shipLocations (list) and the window (graph object)
    Returns: The window (graph object) and ships (list)
    """
    shipIds = []
    ships =[0,0,0,0,0]
    for row in range(len(shipLocations)):
        for collumn in range(len(shipLocations[row])):
            xCoor = 0
            yCoor = 0
            rotation = "horizontal"
            shipLength = 1
            if shipLocations[row][collumn] != 0 and shipLocations[row][collumn] not in shipIds:
                Id = shipLocations[row][collumn]
                shipIds.append(Id)
                try:
                    if shipLocations[row][collumn+1] == Id:
                        shipLength += 1
                        rotation = "horizontal"
                        index = 2
                        clearCondition = True
                        while clearCondition:
                            if shipLocations[row][collumn+index] == Id:
                                shipLength += 1
                                index += 1
                            else:
                                clearCondition = False
                except:
                    pass
                try:
                    if shipLocations[row + 1][collumn] == Id:
                        shipLength += 1
                        rotation = "vertical"
                        clearCondition = True
                        index =2
                        while clearCondition:
                            if shipLocations[row+index][collumn] == Id:
                                shipLength += 1
                                index += 1
                            else:
                                clearCondition = False
                except:
                    pass
                if rotation == "horizontal":
                    xCoor = (collumn + collumn + shipLength)/2 - 0.5
                    yCoor = 9 - row
                else:
                    xCoor = collumn
                    yCoor = 9 - ((row + row + shipLength)/2) + 0.5
                rotation
                shipBody, shipPlacement = drawShip(xCoor, yCoor, rotation, shipLength, window.getWidth(), window)
                ships[Id-1] = shipBody
    return window, ships

def checkEmpty(list):
    """
    Purpose: Checks if lists are empty
    Parameters: The list (list)
    Returns: A boolean
    """
    for row in range(len(list)):
        for collumn in range(len(list[row])):
            if list[row][collumn] != 0:
                return False
    return True

def loadGame(windowDimension):
    """
    Purpose: Loads the game of battleship
    Parameters: The windowDimension (int)
    Returns: The window (graph object)
    """
    shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo = readFile("battleship.data")
    if checkEmpty(shipLocationsOne):
        window = setUpWindow(windowDimension)
        moveText = Text(Point(windowDimension*0.8, windowDimension*0.95), "Your Board")
        moveText.setTextColor("dark red")
        try:
            moveText.setSize(5 + int(windowDimension/25))
        except:
            moveText.setSize(32)
        moveText.draw(window)
        window, shipLocationsOne = pickShipPositions(window, shipLocationsOne, windowDimension)
        writeFile("battleship.data", shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo)
        window.close()
    else:
        window = setUpWindow(windowDimension)
        moveText = Text(Point(windowDimension*0.8, windowDimension*0.95), "Your Board")
        moveText.setTextColor("dark red")
        try:
            moveText.setSize(5 + int(windowDimension/25))
        except:
            moveText.setSize(32)
        moveText.draw(window)
        window, shipsOne = drawFleet(shipLocationsOne, window)
        shipToDestroy = checkShipSunk(shipLocationsOne, spotsFiredOne)
        for ship in range(len(shipsOne)):
            if shipToDestroy[ship] == True:
                 shipsOne[ship].setFill("red")
            try:
                shipsOne[ship].draw(window)
            except:
                shipsOne[ship].undraw()
                shipsOne[ship].draw(window)
        window = drawShots(spotsFiredOne, shipLocationsOne, window)
        time.sleep(1.5)
        if checkFleetSunk(shipToDestroy):
            window = displayWinner(False, window, windowDimension)
            time.sleep(5)
            return window
        window.close()

    window = setUpWindow(windowDimension)
    moveText = Text(Point(windowDimension*0.8, windowDimension*0.95), "Their Board")
    moveText.setTextColor("dark red")
    try:
        moveText.setSize(5 + int(windowDimension/25))
    except:
        moveText.setSize(32)
    moveText.draw(window)
    window, shipsTwo = drawFleet(shipLocationsTwo, window)
    shipToDestroy = checkShipSunk(shipLocationsTwo, spotsFiredTwo)
    for ship in range(len(shipsTwo)):
        if shipToDestroy[ship] == True:
             shipsTwo[ship].setFill("red")
             try:
                 shipsTwo[ship].draw(window)
             except:
                 shipsTwo[ship].undraw()
                 shipsTwo[ship].draw(window)
    window = drawShots(spotsFiredTwo, shipLocationsTwo, window)
    window, spotsTwoFired = fireWeapon(window, window.getWidth(), shipLocationsTwo, spotsFiredTwo)
    shipToDestroy = checkShipSunk(shipLocationsTwo, spotsFiredTwo)
    for ship in range(len(shipsTwo)):
        if shipToDestroy[ship] == True:
            shipsTwo[ship].setFill("red")
            try:
                shipsTwo[ship].draw(window)
            except:
                shipsTwo[ship].undraw()
                shipsTwo[ship].draw(window)
    window = drawShots(spotsFiredTwo, shipLocationsTwo, window)
    writeFile("battleship.data", shipLocationsOne, spotsFiredOne, shipLocationsTwo, spotsFiredTwo)
    if checkFleetSunk(shipToDestroy):
        window = displayWinner(True, window, windowDimension)
        time.sleep(5)
    time.sleep(0.25)
    return window

"""
CLEAN UP below alot: here
"""
def checkShipSunk(shipLocationsOne, spotsFiredOne):
    """
    Purpose: Checks if a ship is sunk
    Parameters: The shipLocationsOne (list) and the spotsFiredOne (list)
    Returns: The shipDestroy (list)
    """
    shipLens = [0,0,0,0,0]
    shipDestroy = [False, False, False, False, False]

    total0 = 0
    total1 = 0
    total2 = 0
    total3 = 0
    total4 = 0
    for line in range(len(shipLocationsOne)):
        for num in range(len(shipLocationsOne[line])):
            if shipLocationsOne[line][num] != 0 and spotsFiredOne[line][num] == True:
                shipLens[shipLocationsOne[line][num] - 1] += 1
            if shipLocationsOne[line][num] == 1:
                total0 += 1
            elif shipLocationsOne[line][num] == 2:
                total1 += 1
            elif shipLocationsOne[line][num] == 3:
                total2 += 1
            elif shipLocationsOne[line][num] == 4:
                total3 += 1
            elif shipLocationsOne[line][num] == 5:
                total4 += 1

    if shipLens[0] == total0:
        shipDestroy[0] = True
    if shipLens[1]== total1:
        shipDestroy[1] = True
    if shipLens[2] == total2:
        shipDestroy[2] = True
    if shipLens[3] == total3:
        shipDestroy[3] = True
    if shipLens[4] == total4:
        shipDestroy[4] = True
    return shipDestroy


def checkFleetSunk(shipToDestroy):
    """
    Purpose: Checks if the whole fleet is sunk
    Parameters: The shipToDestroy (list)
    Returns: A boolean
    """
    for i in shipToDestroy:
        if i == False:
            return False
    return True

def displayWinner(youWin, window, windowDimension):
    """
    Purpose: Displays the winner of the game
    Parameters: The youWin (boolean), the window (graph object), and the windowDimension (int)
    Returns: The window (graph object)
    """
    newLayer = Rectangle(Point(0,0), Point(windowDimension, windowDimension))
    newLayer.setFill("light green")
    newLayer.draw(window)
    if youWin == True:
        winText = Text(Point(windowDimension//2, windowDimension//2), "You Win!")
        try:
            winText.setSize(5 + int(windowDimension/25))
        except:
            winText.setSize(32)
        winText.draw(window)
    else:
        winText = Text(Point(windowDimension//2, windowDimension//2), "You Lose...")
        try:
            winText.setSize(5 + int(windowDimension/25))
        except:
            winText.setSize(32)
        winText.draw(window)
    return window


def main():
    windowDimension = getInput("Enter the dimensions of the window: ")
    menu(windowDimension)

main()
